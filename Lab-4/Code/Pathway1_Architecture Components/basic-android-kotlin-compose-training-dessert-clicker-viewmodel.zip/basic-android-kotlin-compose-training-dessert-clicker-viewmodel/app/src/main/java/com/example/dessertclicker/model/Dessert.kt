package com.example.dessertclicker.model


data class Dessert(val imageId: Int, val price: Int, val startProductionAmount: Int)