package com.example.bookshelf.model

data class BookPhoto(
    val id: String,
    val image: String
)
