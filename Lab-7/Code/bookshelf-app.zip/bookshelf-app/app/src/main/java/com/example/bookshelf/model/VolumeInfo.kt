package com.example.bookshelf.model

@kotlinx.serialization.Serializable
data class VolumeInfo(
    val imageLinks: ImageLinks,

)